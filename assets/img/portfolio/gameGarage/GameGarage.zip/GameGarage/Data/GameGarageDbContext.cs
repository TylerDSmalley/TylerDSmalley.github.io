using System;
using Microsoft.EntityFrameworkCore;
using GameGarage.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace GameGarage.Data
{
    public class GameGarageDbContext : DbContext
    {
        public GameGarageDbContext(DbContextOptions<GameGarageDbContext> options) : base(options) {}
        public DbSet<Score>? Scores { get; set; }
        
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlite(@"Data source=GameGarage.sqlite");
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ScoreConfiguration()).Seed();
        }
    }
}