using GameGarage.Models;
using Microsoft.EntityFrameworkCore;
namespace GameGarage.Data
{
    public static class ModelBuilderExtension
    {
        public static ModelBuilder Seed(this ModelBuilder modelBuilder){
            modelBuilder.Entity<Score>().HasData(
                new Score
                {
                    Id = 1,
                    PlayerName = "Shepard",
                    score = 150,
                },
                new Score
                {
                    Id = 2,
                    PlayerName = "Joe",
                    score = 60,
                },
                new Score
                {
                    Id = 3,
                    PlayerName = "Mary",
                    score = 45,
                },
                new Score
                {
                    Id = 4,
                    PlayerName = "Fred",
                    score = 25,
                },
                new Score
                {
                    Id = 5,
                    PlayerName = "Lisa",
                    score = 16,
                },
                new Score
                {
                    Id = 6,
                    PlayerName = "Mae",
                    score = 15,
                },
                new Score
                {
                    Id = 7,
                    PlayerName = "Aria",
                    score = 12,
                },
                new Score
                {
                    Id = 8,
                    PlayerName = "Tina",
                    score = 9,
                },
                new Score
                {
                    Id = 9,
                    PlayerName = "Liara",
                    score = 7,
                },
                new Score
                {
                    Id = 10,
                    PlayerName = "Garrus",
                    score = 5,
                }
            );
            return modelBuilder;
        }
    }
}