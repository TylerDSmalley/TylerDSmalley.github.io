using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GameGarage.Models
{
    public class Score
    {
        public int Id { get; set; }
        
        [Required, StringLength(25, MinimumLength = 3)]
        public string? PlayerName { get; set; }

        [Required]
        public int score { get; set; }
    }
}