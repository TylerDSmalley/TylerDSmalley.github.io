using Microsoft.AspNetCore.Mvc.RazorPages;
using GameGarage.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace GameGarage.Pages.BrickBreaker
{
    public class IndexModel : PageModel
    {
        private readonly GameGarage.Data.GameGarageDbContext _context;
        public IndexModel(GameGarage.Data.GameGarageDbContext context)
        {
            _context = context;
        }
        public List<Score> HighScores { get; set; }
        public Score HighestScore { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            public int Id { get; set; }

            [Display(Name = "Player's Name")]
            [Required, StringLength(25, MinimumLength = 3)]
            public string PlayerName { get; set; }

            [Display(Name = "Final Score")]
            [Required]
            public int score { get; set; }
        }

        [TempData]
        public string? StatusMessage { get; set; }

        private async Task LoadAsync()
        {
            HighScores = await _context.Scores.OrderByDescending(s => s.score).Take(10).ToListAsync();
            HighestScore = HighScores.First();
        }

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            { 
                var newScore = new Score { PlayerName = Input.PlayerName, score = Convert.ToInt32(Input.score) };
                _context.Scores.Add(newScore);
                await _context.SaveChangesAsync();
                StatusMessage = "Your score has been saved. If your're in the top ten, you'll see yourself on the leaderboard!";
            }
            await LoadAsync();
            return Page();
        }
    }
}
