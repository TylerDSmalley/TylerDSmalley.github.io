import Game from "./game.js";

let canvas = document.getElementById("gameScreen");
let ctx = canvas.getContext('2d');
let scoreBox = document.getElementById("scoreBox");
let lifeBox = document.getElementById("lifeBox");
let levelNum = document.getElementById("levelNum");
let levelName = document.getElementById("levelName");

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

let game = new Game(GAME_WIDTH, GAME_HEIGHT);
let lastTime = 0;

// recursive function
function gameLoop(timestamp) {
    let deltaTime = timestamp - lastTime;
    lastTime = timestamp;
    scoreBox.innerText =  game.score;
    lifeBox.innerText = game.lives;
    levelNum.innerText = game.currentLevel +1;
    levelName.innerText = game.currentLevelName;

    ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    game.update(deltaTime);
    game.draw(ctx);

    requestAnimationFrame(gameLoop);
}

requestAnimationFrame(gameLoop);
