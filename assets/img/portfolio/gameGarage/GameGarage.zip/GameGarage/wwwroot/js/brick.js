import { detectCollision } from "./collisionDetection.js"

export default class Brick {
    //array of initial brick images
    bricksImages = [
        document.getElementById("1"),
        document.getElementById("3"),
        document.getElementById("5"),
        document.getElementById("7"),
        document.getElementById("9"),
        document.getElementById("11"),
        document.getElementById("13"),
        document.getElementById("15"),
        document.getElementById("17"),
        document.getElementById("19"),
        
        // Cracked brick set for future easy mode
        // document.getElementById("2"),
        // document.getElementById("4"),
        // document.getElementById("6"),
        // document.getElementById("8"),
        // document.getElementById("10"),
        // document.getElementById("12"),
        // document.getElementById("14"),
        // document.getElementById("16"),
        // document.getElementById("18"),
        // document.getElementById("20"),
    ];

    constructor(game, position) {
        this.image = this.randomBrick(this.bricksImages);
        this.game = game;
        this.position = position;
        this.width = 80;
        this.height = 24;
        this.markedForDeletion = false;
    }

    update() {
        if(detectCollision(this.game.ball, this)) {
            this.game.ball.speed.y = -this.game.ball.speed.y;
            //check the image to determine the brick state - first or second impact
            let currentImageId = (parseInt(this.image.id));
            //if the current image has an even number for an ID, 
            //it's already cracked and should be marked for deletion
            if(currentImageId % 2 == 0) {
                this.markedForDeletion = true;
            } else { 
                //if ID is odd, it's a fresh brick and image should be swapped to it's cracked counterpart
                //This is done by changing the brick's assigned image. Every pristine brick has an odd number 
                //while it's cracked counterpart has an even number. To change the brick image to cracked state,
                //add +1 to the current image ID.
                let crackedBrickId = currentImageId + 1
                this.image = document.getElementById(crackedBrickId.toString());
            }
        }
    }

    draw(ctx) {
        ctx.drawImage(
            this.image, 
            this.position.x, 
            this.position.y, 
            this.width, 
            this.height)
    }

    //picks a random brick color to fill the level array
    randomBrick(bricks) {
        return bricks[Math.floor(Math.random() * bricks.length)];
    }
}