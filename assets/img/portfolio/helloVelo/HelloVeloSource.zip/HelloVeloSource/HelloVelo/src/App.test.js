import { render } from '@testing-library/react';
import Footer from './Components/Footer';
  
test('Footer renders without crashing', () => {
  render(<Footer />);
});
