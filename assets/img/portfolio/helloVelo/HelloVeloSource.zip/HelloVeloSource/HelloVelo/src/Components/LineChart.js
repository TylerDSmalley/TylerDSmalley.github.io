import React from 'react'
import { Line } from "react-chartjs-2";
import {Chart as ChartJS} from 'chart.js/auto'

function LineChart({chartData}) {
  return (
    <div>
    <Line
      data={chartData}
      options={{
        plugins: {
          title: {
            display: true,
            text: "Number of Rentals Per Day from the Past 7 days"
          },
          legend: {
            display: false
          }

        }
      }}
    />
  </div>
  )
}

export default LineChart