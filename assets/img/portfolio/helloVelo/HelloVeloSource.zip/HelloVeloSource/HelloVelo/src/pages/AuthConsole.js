import React from "react";
import { Navigate, useOutlet } from 'react-router-dom'
import Home from "./Home";

export default function AuthConsole() {
    const outlet = useOutlet();
    
    /* 
    If there the root is being accessed, meaning there's no outlet, return Home page
    if there is an outlet but no one is logged in, navigate back to root
    otherwise return the outlet
    */
    if(!outlet){
        return <Home />
    } else if (!localStorage.getItem('accessToken')){
        return <Navigate to="/" />
    } else {
        return outlet;
    }

}