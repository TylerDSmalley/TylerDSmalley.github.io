import React, { useContext } from "react";
import logo from './logo.svg';
import './styles/Admin.css';
import { useOutlet, Navigate } from 'react-router-dom'
import { AuthContext } from "../../helpers/AuthContext";
import AdminDashboard from './dashboard/AdminDashboard';

export default function AdminConsole() {
    const outlet = useOutlet();
    const { authState } = useContext(AuthContext);
    
    //-- restrict access to non-admins --//
    if(authState.roles && !authState.roles.includes('ADMIN')){
        return <Navigate to="/" />
    }
    //--|--//
    return (
        <>
        {outlet ?? 

            <AdminDashboard/>
        }
        </>
    )
}