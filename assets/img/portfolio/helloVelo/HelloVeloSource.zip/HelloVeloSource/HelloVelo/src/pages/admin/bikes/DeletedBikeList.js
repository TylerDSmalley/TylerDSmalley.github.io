import React from 'react';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
//MUI
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TablePagination from '@mui/material/TablePagination';
import Button from '@mui/material/Button';

export default function DeletedBikeList() {
    const [listOfBikes, setListOfBikes] = useState([]);
    let navigate = useNavigate();

    useEffect(() => {
        axios.get(`/api/admin/bikes?deleted=true`, {
            headers: {
                Authorization: 'Bearer ' + localStorage.getItem('accessToken')
            }
        }).then((response) => {
            setListOfBikes(response.data);
        });
    }, []);


    const addBike = () => {
        navigate('/admin/bikes/create')
    }

    function createData(id, bikeType, currentlyInUse, lastMaintenance, serialNumber, status) {
        return { id, bikeType, currentlyInUse, lastMaintenance, serialNumber, status };
    }

    const rows = listOfBikes.map((value) => (
        createData(value.id, value.bikeType, value.currentlyInUse, value.lastMaintenance, value.serialNumber, value.status)
    ))

    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);


    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    return (
        <div className='full-vh'>
            <div className='d-flex justify-content-center bg-grey '>
                <TableContainer
                    className='mt-5 w-75 shadow'
                    component={Paper}
                >
                    <Button
                        className="bg-info text-white m-2 align-middle"
                        onClick={
                            () => {
                                navigate(`/admin/bikes/`)
                            }
                        }
                    >Bike List</Button>
                    <h1 className='text-center mt-2'>List of Removed Bikes</h1>
                    <Table className='shadow-sm mb-3' sx={{ minWidth: 850 }} aria-label="simple table">
                        <TableHead className='shadow-sm'>
                            <TableRow>
                                <TableCell align="right">ID</TableCell>
                                <TableCell align="right">Bike Type</TableCell>
                                <TableCell align="right">Currently In Use</TableCell>
                                <TableCell align="right">Last Maintenance</TableCell>
                                <TableCell align="right">Serial Number</TableCell>
                                <TableCell align="right">Status</TableCell>
                                {/* <TableCell align="center">Actions</TableCell> */}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
                                <TableRow
                                    key={row.id}
                                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                >
                                    <TableCell align="right">{row.id}</TableCell>
                                    <TableCell align="right">{row.bikeType}</TableCell>
                                    <TableCell align="right">{row.currentlyInUse.toString()}</TableCell>
                                    <TableCell align="right">{row.lastMaintenance}</TableCell>
                                    <TableCell align="right">{row.serialNumber}</TableCell>
                                    <TableCell align="right">{row.status}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <div className='d-flex flex-wrap justify-content-between'>
                        <Button
                            className="bg-info text-white m-2 align-middle"
                            onClick={addBike}
                        >
                            Add Bike
                        </Button>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            component="div"
                            count={rows.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        ></TablePagination>
                    </div>
                </TableContainer>
            </div>
        </div>

    )
}