
import React, { useEffect, useState } from "react";
import {useParams} from 'react-router-dom';
import axios from "axios";
import EditBike from "./EditBike";

export default function EditBikeHelper() {
    let { id } = useParams();
  const [data, setData] = useState(null);


    useEffect(() => {
         axios.get(`/api/admin/bikes/edit/${id}`, {
        headers: {
            Authorization: 'Bearer ' + localStorage.getItem('accessToken')
        }
    }).then((response) => {
            setData(response.data);
    });
        
    }, [id]);
  return data? <EditBike preloadedValues={data}/> : <div>Loading...</div>
}

