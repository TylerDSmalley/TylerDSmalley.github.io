import React, { useContext } from "react";
import '../styles/Admin.css';
import { useOutlet, Navigate } from 'react-router-dom'
import PromoList from "./PromoList";
import { AuthContext } from "../../../helpers/AuthContext";

export default function AdminPromos() {
    const outlet = useOutlet();
    const { authState } = useContext(AuthContext);

    //-- restrict access to non-admins --//
    if (authState.roles && !authState.roles.includes('ADMIN')) {
        return <Navigate to="/" />
    }
    //--|--//
    return (
        <>
            {outlet ??

                <PromoList />
            }
        </>
    )
}