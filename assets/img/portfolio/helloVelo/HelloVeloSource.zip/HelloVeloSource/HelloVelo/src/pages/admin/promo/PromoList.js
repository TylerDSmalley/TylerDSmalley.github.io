import React from 'react';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
//MUI
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TablePagination from '@mui/material/TablePagination';
import Button from '@mui/material/Button';

export default function PromoList() {
    const [listOfCustomers, setListOfCustomers] = useState([]);
    const [listOfPromos, setListOfPromos] = useState([]);
    let navigate = useNavigate();

    useEffect(() => {
        axios.get(`/api/admin/coupons/visible`, {
            headers: {
                Authorization: 'Bearer ' + localStorage.getItem('accessToken')
            }
        }).then((response) => {
            console.log(response.data)
            setListOfPromos(response.data);
        });
    }, []);

    const deletePromo = (id) => {
        navigate(`/admin/promos/delete/${id}`);
    };

    const editPromo = (id) => {
        navigate(`/admin/promos/update/${id}`);
    };

    const addPromo = () => {
        navigate('/admin/promos/create')
    }

    const sendPromo = () => {
        navigate('/admin/promos/send')
    }

    function createData(id, title, percentOff, amountOff, status, stripeCouponId, expirationDate) {
        return { id, title, percentOff, amountOff, status, stripeCouponId, expirationDate };
    }

    const rows = listOfPromos.map((value) => (
        createData(value.id, value.title, (value.percentOff ? (value.percentOff) : "N/A"), (value.amountOff ? (value.amountOff / 100) : "N/A"), value.status, value.stripeCouponId, value.expirationDate)
    ))

    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);


    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleSend = () => {

    }

    return (
        <div className='full-vh'>
            <div className='d-flex justify-content-center bg-grey '>
                <TableContainer
                    className='mt-5 w-75 shadow'
                    component={Paper}
                >
                    <h1 className='text-center mt-2'>List of promos</h1>
                    <Table className='shadow-sm mb-3' sx={{ minWidth: 850 }} aria-label="simple table">
                        <TableHead className='shadow-sm'>
                            <TableRow>
                                <TableCell align="right">ID</TableCell>
                                <TableCell align="right">Title</TableCell>
                                <TableCell align="right">Percent Off</TableCell>
                                <TableCell align="right">Amount Off ($)</TableCell>
                                <TableCell align="right">Status</TableCell>
                                <TableCell align="right">Stripe Coupon Id</TableCell>
                                <TableCell align="right">Expiration Date</TableCell>
                                <TableCell align="center">Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
                                <TableRow
                                    key={row.id}
                                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                >
                                    <TableCell align="right">{row.id}</TableCell>
                                    <TableCell align="right">{row.title}</TableCell>
                                    <TableCell align="right">{row.percentOff}</TableCell>
                                    <TableCell align="right">{row.amountOff}</TableCell>
                                    <TableCell align="right">{row.status}</TableCell>
                                    <TableCell align="right">{row.stripeCouponId}</TableCell>
                                    <TableCell align="right">{row.expirationDate}</TableCell>
                                    {/* {row.StationName !== null && (<TableCell align="right">{row.StationName}</TableCell>)} */}
                                    <TableCell align="right">
                                        <Button className="bg-secondary text-white mx-2" onClick={() => { editPromo(row.id) }}>Edit!</Button>
                                        <Button className="bg-danger text-white" onClick={() => { deletePromo(row.id) }}>Delete</Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <div className='d-flex flex-wrap justify-content-end'>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            component="div"
                            count={rows.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        ></TablePagination>
                        <Button
                            className="bg-info text-white m-2 align-middle"
                            onClick={addPromo}
                        >
                            Add Promo
                        </Button>
                        <Button
                            className="bg-info text-white m-2 align-middle"
                            onClick={sendPromo}
                        >
                            Send Promos
                        </Button>

                    </div>
                </TableContainer>
            </div>
        </div>

    )
}