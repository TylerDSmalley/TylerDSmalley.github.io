import React, { useContext } from "react";
import '../styles/Admin.css';
import { useOutlet, Navigate } from 'react-router-dom'
import { AuthContext } from "../../../helpers/AuthContext";
import RentalList from "./RentalList";

export default function AdminRentals() {
    const outlet = useOutlet();
    const { authState } = useContext(AuthContext);
    
    if(authState.roles && !authState.roles.includes('ADMIN')){
        return <Navigate to="/" />
    }
    //--|--//
    return (
        <>
        {outlet ?? 

            <RentalList/>
        }
        </>
    )
}