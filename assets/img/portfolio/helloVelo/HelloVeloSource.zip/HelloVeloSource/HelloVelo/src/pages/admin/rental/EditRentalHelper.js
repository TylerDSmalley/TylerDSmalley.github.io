
import React, { useEffect, useState } from "react";
import {useParams} from 'react-router-dom';
import axios from "axios";
import EditRental from "./EditRental";

export default function EditRentalHelper() {
    let { id } = useParams();
  const [data, setData] = useState(null);


    useEffect(() => {
         axios.get(`/api/admin/rentals/edit/${id}`, {
        headers: {
            Authorization: 'Bearer ' + localStorage.getItem('accessToken')
        }
    }).then((response) => {
            setData(response.data);
          });
        
    }, [id]);
  return (data!== null)? <EditRental preloadedValues={data}/> : <div>Loading...</div>
}

