import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
//MUI
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import TablePagination from '@mui/material/TablePagination';
var striptags = require('striptags');

function ReportsList() {
    const [listOfReports, setListOfReports] = useState([]);
    let navigate = useNavigate();

    useEffect(() => {
        axios.get(`/api/admin/reports`, {
            headers: {
                Authorization: 'Bearer ' + localStorage.getItem('accessToken')
            }
        }).then((response) => {
            setListOfReports(response.data);
        });
    }, []);

    function createData(id, body, reportTime, bikeSerialNumber, stationName, username) {
        return { id, body, reportTime, bikeSerialNumber, stationName, username };
    }

    const rows = listOfReports.map((value) => (
        createData(value.id, value.body, value.reportTime, value.bike ? value.bike.serialNumber : "N/A", value.station ? value.station.name : "N/A", value.user.username)
    ))

    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);


    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const deleteReport = (id) => {
        navigate(`/admin/reports/delete/${id}`);
    };

    const viewReport = (id) => {
        navigate(`/admin/reports/view/${id}`);
    };

    function smart_substr(str) {
        return str.length > 20 ? str.substring(0, 10) + "..." : str;
    }

    return (
        <div className='full-vh'>
            <div className='d-flex justify-content-center'>
                <TableContainer
                    className='mt-5 w-75 shadow'
                    component={Paper}
                >
                    <h1 className='text-center mt-2'>List of Reports</h1>
                    <Table className='shadow-sm mb-3' sx={{ minWidth: 850 }} aria-label="simple table">
                        <TableHead className='shadow-sm'>
                            <TableRow>
                                <TableCell align="right">ID</TableCell>
                                <TableCell align="right">Report Body</TableCell>
                                <TableCell align="right">Date | Time</TableCell>
                                <TableCell align="right">Station Name</TableCell>
                                <TableCell align="right">Bike Serial Number</TableCell>
                                <TableCell align="center">Username</TableCell>
                                <TableCell align="center">Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
                                <TableRow
                                    key={row.id}
                                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                >
                                    <TableCell align="right">{row.id}</TableCell>
                                    <TableCell align="right">{smart_substr(striptags(row.body))}</TableCell>
                                    <TableCell align="right">{row.reportTime}</TableCell>
                                    <TableCell align="right">{row.stationName}</TableCell>
                                    <TableCell align="right">{row.bikeSerialNumber}</TableCell>
                                    <TableCell align="right">{row.username}</TableCell>

                                    <TableCell align="right">

                                        <Button className="bg-primary text-white mx-2" onClick={() => { viewReport(row.id) }}>View</Button>
                                        <Button className="bg-danger text-white mx-2" onClick={() => { deleteReport(row.id) }}>Delete</Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <div className='d-flex flex-wrap justify-content-between'>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            component="div"
                            count={rows.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        ></TablePagination>
                    </div>
                </TableContainer>
            </div>
        </div>
    )
}

export default ReportsList