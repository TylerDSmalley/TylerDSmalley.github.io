import React, { useEffect, useState } from "react";
import {useParams} from 'react-router-dom';
import axios from "axios";
import EditStation from "./EditStation";

export default function EditStationHelper() {
    let { id } = useParams();
    const [error, setError] = useState('');
    const [data, setData] = useState(null);

    useEffect(() => {
        axios.get(`/api/admin/stations/${id}`, {
        headers: {
            Authorization: 'Bearer ' + localStorage.getItem('accessToken')
        }
    }).then((response) => {
            setData(response.data);
        })
        .catch((error) => {
            if(error.response.data.message) {
                setError(error.response.data.message);
            }
        });
    }, [id]);

    return data? <EditStation preloadedValues={data}/> : ({error}? <span className="text-danger">{error}</span> : <div>Loading...</div>)
    
}

 