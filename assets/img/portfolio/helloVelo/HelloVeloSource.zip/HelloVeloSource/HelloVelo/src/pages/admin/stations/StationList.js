import React from 'react';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
//MUI
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TablePagination from '@mui/material/TablePagination';
import Button from '@mui/material/Button';

export default function StationList() {
    const [listOfStations, setListOfStations] = useState([]);
    let navigate = useNavigate();

    useEffect(() => {
        axios.get(`/api/admin/stations`, {
            headers: {
                Authorization: 'Bearer ' + localStorage.getItem('accessToken')
            }
        }).then((response) => {
            setListOfStations(response.data);
        });
    }, []);

    const deleteStation = (id) => {
        navigate(`/admin/stations/delete/${id}`);
    };

    const editStation = (id) => {
        navigate(`/admin/stations/update/${id}`);
    };

    const addStation = () => {
        navigate('/admin/stations/create')
    }

    const transferBikes = (id) => {
        navigate(`/admin/stations/transfer-bikes/${id}`)
    }

    function createData(id, latitude, longitude, name, status, totalSlots, availableSlots, numberOfBikes) {
        return { id, latitude, longitude, name, status, totalSlots, availableSlots, numberOfBikes };
    }

    const rows = listOfStations.map((value) => (
        createData(value.id, value.latitude, value.longitude, value.name, value.status, value.totalSlots, value.availableSlots, value.numberOfBikes)
    ))

    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);


    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    return (
        <div className='full-vh'>
            <div className='d-flex justify-content-center bg-grey '>
                <TableContainer
                    className='mt-5 w-75 shadow'
                    component={Paper}
                >
                    <h1 className='text-center mt-2'>List of Stations</h1>
                    <Table className='shadow-sm mb-3' sx={{ minWidth: 850 }} aria-label="simple table">
                        <TableHead className='shadow-sm'>
                            <TableRow>
                                <TableCell align="right">ID</TableCell>
                                {/* <TableCell align="right">Latitude</TableCell>
                                <TableCell align="right">Longitude</TableCell> */}
                                <TableCell align="right">Station Name</TableCell>
                                <TableCell align="right">Status</TableCell>
                                <TableCell align="center">Total Slots</TableCell>
                                <TableCell align="center">Empty Slots</TableCell>
                                <TableCell align="center">Number Of Bikes</TableCell>
                                <TableCell align="center">Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
                                <TableRow
                                    key={row.id}
                                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                >
                                    <TableCell align="right">{row.id}</TableCell>
                                    {/* <TableCell align="right">{row.latitude}</TableCell>
                                    <TableCell align="right">{row.longitude}</TableCell> */}
                                    <TableCell align="right">{row.name}</TableCell>
                                    <TableCell align="right">{row.status}</TableCell>
                                    <TableCell align="right">{row.totalSlots}</TableCell>
                                    <TableCell align="right">{row.availableSlots}</TableCell>
                                    <TableCell align="right">{row.numberOfBikes}</TableCell>
                                    <TableCell align="right">
                                        <Button className="bg-secondary text-white mx-2" onClick={() => { editStation(row.id) }}>Edit!</Button>
                                        <Button className="bg-danger text-white mx-2" onClick={() => { deleteStation(row.id) }}>Delete</Button>
                                        <Button className="bg-primary text-white" onClick={() => { transferBikes(row.id) }}>Transfer Bikes</Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <div className='d-flex flex-wrap justify-content-between'>
                        <Button
                            className="bg-info text-white m-2 align-middle"
                            onClick={addStation}
                        >
                            Add Station
                        </Button>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            component="div"
                            count={rows.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        ></TablePagination>
                    </div>
                </TableContainer>
            </div>
        </div>

    )
}