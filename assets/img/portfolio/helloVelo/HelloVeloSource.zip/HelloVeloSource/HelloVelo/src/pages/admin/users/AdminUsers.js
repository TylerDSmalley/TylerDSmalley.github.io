import React, { useContext } from "react";
import '../styles/Admin.css';
import { useOutlet, Navigate } from 'react-router-dom'
import { AuthContext } from "../../../helpers/AuthContext";
import UserList from './UserList';

export default function AdminUsers() {
    const outlet = useOutlet();
    const { authState } = useContext(AuthContext);
    
    //-- restrict access to non-admins --//
    if(authState.roles && !authState.roles.includes('ADMIN')){
        return <Navigate to="/" />
    }
    //--|--//
    return (
        <>
        {outlet ?? 

            <UserList/>
        }
        </>
    )
}