import React, { useEffect, useState } from "react";
import axios from "axios";
import Profile from "./Profile";

export default function ProfileHelper() {
    const [error, setError] = useState('');
    const [data, setData] = useState(null);
 
    useEffect(() => {

        axios.get(`/api/profile`, {
        headers: {
            Authorization: 'Bearer ' + localStorage.getItem('accessToken')
        }
    }).then((response) => {
            setData(response.data);
        })
        .catch((error) => {
            if(error.response.data.message) {
                setError(error.response.data.message);
            }
        });
    }, []);

    return data? <Profile preloadedValues={data}/> : ({error}? <span className="text-danger">{error}</span> : <div>Loading...</div>)

}

