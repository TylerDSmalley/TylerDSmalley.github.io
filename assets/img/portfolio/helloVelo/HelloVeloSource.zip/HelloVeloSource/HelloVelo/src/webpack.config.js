import { EnvironmentPlugin } from 'webpack';
import HtmlWebpackPlugin from 'html-webpack-plugin';

export const mode = 'development';
export const entry = {
    app: './app.js'
};
export const devtool = 'source-map';
export const module = {
    rules: [
        {
            test: /\.css$/,
            use: ['style-loader', 'css-loader']
        },
        {
            test: /\.js$/,
            exclude: [/node_modules/],
            use: [
                {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/env', '@babel/react']
                    }
                }
            ]
        }
    ]
};
export const plugins = [
    new HtmlWebpackPlugin({ title: 'react-map-gl Example' }),
    new EnvironmentPlugin({ MapboxAccessToken: `${process.env.REACT_APP_MAPBOX_PUBLIC_KEY}` })
];