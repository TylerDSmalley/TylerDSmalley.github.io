package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Station;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.service.BikeService;
import com.fsd.hellovelo.service.StationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/bikes")
public class BikeUserController {

    private final BikeService bikeService;


    @Autowired
    public BikeUserController(BikeService bikeService) {
        this.bikeService = bikeService;
    }

    @GetMapping("")
    public List<Bike> getAllBikes() {
        return bikeService.findAllBikesUsers();
    }

    @GetMapping(path = "{bikeId}")
    public ResponseEntity<?> getBike(@PathVariable("bikeId") Long bikeId) {
        try {
            Bike bike = bikeService.getBikeUsers(bikeId);
            return ResponseEntity.status(HttpStatus.OK).body(bike);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }
}
