package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.entity.Coupon;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.RentalRequest;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.service.CouponService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/api/admin/coupons")
public class CouponController {

    private final CouponService couponService;

    @Autowired
    public CouponController (CouponService couponService){
        this.couponService = couponService;
    }

    //create
    @PostMapping("/")
    public ResponseEntity<?> createCoupon(@RequestBody @Valid Coupon coupon) {
        try {
            couponService.createCoupon(coupon);
            return ResponseEntity.status(HttpStatus.OK).body("");
        }
        catch (ResourceNotFoundException | StripeException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    //retrieve
    @GetMapping("/")
    public ResponseEntity<?> getCoupons() {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(couponService.getAllCoupons());
        }
        catch (ResourceNotFoundException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @GetMapping("/visible")
    public ResponseEntity<?> getVisibleCoupons() {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(couponService.getAllVisibleCoupons());
        }
        catch (ResourceNotFoundException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getCoupon(@PathVariable Long id) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(couponService.getCoupon(id));
        }
        catch (ResourceNotFoundException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    //update
    //coupons on stripe cannot be edited, so there's no point for us to edit it
//    @PutMapping("/{id}")
//    public ResponseEntity<?> updateCoupon(@PathVariable Long id, @RequestBody Coupon coupon) {
//        try {
//            couponService.updateCoupon(id, coupon);
//            return ResponseEntity.status(HttpStatus.OK).body("");
//        }
//        catch (ResourceNotFoundException | IllegalArgumentException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
//        }
//    }

    //delete
    //note that this is a soft delete - no records are removed.
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCoupon(@PathVariable Long id) {
        try {
            couponService.deleteCoupon(id);
            return ResponseEntity.status(HttpStatus.OK).body("");
        }
        catch (ResourceNotFoundException | StripeException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }
}
