package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.CreateIndividualPromotionEmailRequest;
import com.fsd.hellovelo.service.SendGridEmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/api/admin/email")
public class EmailController {

    private final SendGridEmailService sendGridEmailService;

    @Autowired
    public EmailController(SendGridEmailService sendGridEmailService){
        this.sendGridEmailService = sendGridEmailService;
    }

    @PostMapping("/sendReturningDiscount")
    public ResponseEntity<?> sendEmail(@RequestBody @Valid CreateIndividualPromotionEmailRequest discountEmailData){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(sendGridEmailService.sendDiscountEmail(discountEmailData));
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
