package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Maintenance;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.BikeTransferRequest;
import com.fsd.hellovelo.payload.request.MaintenanceTransferRequest;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.service.BikeService;
import com.fsd.hellovelo.service.MaintenanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/api/admin/maintenance")
public class MaintenanceController {

    @Autowired
    private final BikeService bikeService;

    @Autowired
    private final MaintenanceService maintenanceService;


    @Autowired
    public MaintenanceController(BikeService bikeService, MaintenanceService maintenanceService) {
        this.bikeService = bikeService;
        this.maintenanceService = maintenanceService;
    }

    // **********************************  LIST OF BIKES FOR MAINTENANCE **********************************
    @GetMapping
    public List<Bike> getAllBikesMaintenanceList() {
        return maintenanceService.findAllBikesDueForMaintenance();
    }

    // **********************************  All Maintenance History **********************************
    @GetMapping("/history")
    public List<Maintenance> getAllHistory() {
        return maintenanceService.findAllMaintenanceHistory();
    }

    // ********************************** TRANSFER BIKES TO STATION 1 AFTER MAINTENANCE **********************************
    @PostMapping(path = "{bikeId}")
    public ResponseEntity<?> transferBikesToStation1(@PathVariable("bikeId") Long bikeId) {
        try {
            maintenanceService.makeBikeStatusActiveAfterMaintenance(bikeId);
            return ResponseEntity.status(HttpStatus.OK).body("Bike is Maintained");
            //List<Maintenance> maintainedBikeList= maintenanceService.transferBikesToMaintenance(maintenanceTransferRequest);
            //return ResponseEntity.status(HttpStatus.OK).body(maintainedBikeList);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
        catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }


    // ********************************** TRANSFER Reported Bike For Maintenance **********************************
    @PostMapping(path = "reported/{reportId}")
    public ResponseEntity<?> transferReportedBikeToMaintenance(@PathVariable("reportId") Long reportId) {
        try {
            maintenanceService.sendReportedBikeToMaintenance(reportId);
            return ResponseEntity.status(HttpStatus.OK).body("Bike is sent to maintenance list");
            //List<Maintenance> maintainedBikeList= maintenanceService.transferBikesToMaintenance(maintenanceTransferRequest);
            //return ResponseEntity.status(HttpStatus.OK).body(maintainedBikeList);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
        catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }
}
