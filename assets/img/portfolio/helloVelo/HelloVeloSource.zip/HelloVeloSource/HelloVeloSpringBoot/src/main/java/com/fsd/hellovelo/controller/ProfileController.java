package com.fsd.hellovelo.controller;
import com.fsd.hellovelo.entity.Station;
import com.fsd.hellovelo.entity.User;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.UpdateProfileRequest;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.payload.response.SubscriptionAndInvoiceResponse;
import com.fsd.hellovelo.repository.UserRepository;
import com.fsd.hellovelo.security.services.UserDetailsImpl;
import com.fsd.hellovelo.service.ProfileService;
import com.fsd.hellovelo.service.StationService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN') || hasRole('USER')")
@RequestMapping("/api/profile")
public class ProfileController {

    private final ProfileService profileService;

    @Autowired
    UserRepository userRepository;

    @Autowired
    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @GetMapping("/subscriptionDetails")
    public ResponseEntity<?> getSubscriptionAndInvoiceResponse() {
        try {
            SubscriptionAndInvoiceResponse response = profileService.getSubAndInvoiceDetails();
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }
        catch(ResourceNotFoundException | StripeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @GetMapping()
    public ResponseEntity<?> getProfile() {
        try {
            User user = profileService.getUser();
            return ResponseEntity.status(HttpStatus.OK).body(user);
        }
        catch(ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
        catch(ClassCastException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }

    @PutMapping()
        public ResponseEntity<?> updateProfile(@Valid @RequestBody UpdateProfileRequest updateProfileRequest) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(profileService.updateProfile(updateProfileRequest));
        }
        catch(ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
        catch(ClassCastException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }

    @DeleteMapping()
    public ResponseEntity<?> deactivateAccount() {
        try {
            profileService.deactivateAccount();
            return ResponseEntity.status(HttpStatus.OK).body(new MessageResponse("Your account was deleted"));
        }
        catch(ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
        catch(ClassCastException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }
}
