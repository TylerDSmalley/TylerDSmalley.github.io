package com.fsd.hellovelo.controller;
import com.fsd.hellovelo.entity.Referral;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.service.ReferralService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.naming.Reference;
import javax.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/referrals")
public class ReferralController {

    private final ReferralService referralService;

    @Autowired
    public ReferralController(ReferralService referralService){
        this.referralService = referralService;
    }

    @PostMapping("/")
    public ResponseEntity<?> createReferral(@RequestBody @Valid Referral referral) {
        try{
            referralService.createReferral(referral);
            return ResponseEntity.status(HttpStatus.OK).body("");
        } catch (ResourceNotFoundException | IllegalArgumentException | StripeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }
}
