package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Rental;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.RentalRequest;
import com.fsd.hellovelo.payload.request.UpdateBikeRequest;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/api/admin/rentals")
public class RentalController {

    private final RentalService rentalService;

    @Autowired
    public RentalController(RentalService rentalService){
        this.rentalService = rentalService;
    }

//    @GetMapping()
//    public ResponseEntity<?> getAllRentals() {
//        try {
//            List<Rental> rentals =  rentalService.getRentals();
//            return ResponseEntity.status(HttpStatus.OK).body(rentals);
//        }
//        catch (ResourceNotFoundException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//        }
//    }


    /************************************************* RENTAL LIST PAGINATED **********************************************************************/
    @GetMapping()
    public ResponseEntity<?> getAllRentals(int pageNumber, int pageSize, String sortBy, String sortDir) {
        try {
            Page<Rental> rentals =  rentalService.paginatedRentalList(pageNumber,pageSize,sortBy,sortDir);
            return ResponseEntity.status(HttpStatus.OK).body(rentals);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    /************************************************* SEARCH IN PAGINATED RENTAL LIST **************************************************************/
    @GetMapping("/search/{searchText}")
    public ResponseEntity<?> getAllRentalsWithSearch(int pageNumber, int pageSize, String sortBy, String sortDir, @PathVariable String searchText) {
        try {
            Page<Rental> rentals =  rentalService.paginatedRentalList(pageNumber,pageSize,sortBy,sortDir,searchText);
            return ResponseEntity.status(HttpStatus.OK).body(rentals);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }




    @GetMapping(path = "{id}")
    public ResponseEntity<?> getRental(@PathVariable("id") Long id) {
        try {
            Rental rental =  rentalService.getRental(id);
            System.out.println(rental);
            return ResponseEntity.status(HttpStatus.OK).body(rental);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }


    @GetMapping(path = "/edit/{rentalId}")
    public ResponseEntity<?> getRentalModelById (@PathVariable("rentalId") Long rentalId){
        try {
            Rental rental =  rentalService.getRental(rentalId);
            System.out.println(rental);
            RentalRequest rentalModel = new RentalRequest();
            rentalModel.setId(rental.getId());
            rentalModel.setStartTime(rental.getStartTime());
            rentalModel.setEndTime(rental.getEndTime());
            rentalModel.setBikeId(rental.getBike().getId());
            rentalModel.setStartStationId(rental.getStartStation().getId());
            if (rental.getEndStation() != null) {
            rentalModel.setEndStationId(rental.getEndStation().getId());}
            else {
                rentalModel.setEndStationId(0L);
            }
            rentalModel.setUserId(rental.getUser().getId());
            System.out.println(rentalModel);
            return ResponseEntity.status(HttpStatus.OK).body(rentalModel);
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @PutMapping("/")
    public ResponseEntity<?> updateUser(@RequestBody @Valid RentalRequest rental) {
        try {
            Rental currRental = rentalService.updateRental(rental);
            return ResponseEntity.status(HttpStatus.OK).body(currRental);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body( new MessageResponse(e.getMessage()));
        }
        catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }

    @GetMapping("/weeklyStats")
    public ResponseEntity<?> getWeeklyStats() {
        return ResponseEntity.status(HttpStatus.OK).body(rentalService.getWeeklyStats());
    }


}
