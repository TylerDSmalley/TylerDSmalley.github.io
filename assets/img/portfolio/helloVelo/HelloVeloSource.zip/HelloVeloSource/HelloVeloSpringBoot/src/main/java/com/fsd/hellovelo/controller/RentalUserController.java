package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Rental;
import com.fsd.hellovelo.entity.User;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.RentalRequest;
import com.fsd.hellovelo.payload.request.UserRentalRequest;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.repository.BikeRepository;
import com.fsd.hellovelo.service.UserRentalService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/rental")
@PreAuthorize("hasRole('USER')")
public class RentalUserController {

    private final UserRentalService userRentalService;

    @Autowired
    public RentalUserController(UserRentalService userRentalService){
        this.userRentalService = userRentalService;
    }

//    @PostMapping("/start")
//    public ResponseEntity<?> rentBike(@RequestBody @Valid UserRentalRequest userRentalRequest) {
//        try {
//            Bike bike = userRentalService.findBikeBySerialNumber(userRentalRequest);
//            RentalRequest rental = new RentalRequest();
//            rental.setBikeId(bike.getId());
//            userRentalService.rentBike(rental);
//            return ResponseEntity.status(HttpStatus.OK).body("");
//        }
//        catch (ResourceNotFoundException | IllegalArgumentException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
//        }
//    }

    @PostMapping("/start")
    public ResponseEntity<?> rentBike(@RequestBody @Valid RentalRequest rental) {
        try {
            userRentalService.rentBike(rental);
            return ResponseEntity.status(HttpStatus.OK).body("");
        }
        catch (ResourceNotFoundException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @PutMapping("/end")
    public ResponseEntity<?> returnBike(@RequestBody @Valid RentalRequest rental) {
        try {
            userRentalService.returnBike(rental);
            return ResponseEntity.status(HttpStatus.OK).body("");
        }
        catch (ResourceNotFoundException | StripeException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @GetMapping("")
    public ResponseEntity<?> getCurrentRental() {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(userRentalService.getCurrentRental());
        }
        catch (ResourceNotFoundException | IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    /**********************************LIST OF USER RENTAL PAGINATED WITH SORTING **************************************/

    @GetMapping("/history")
    public ResponseEntity<?> getAllCurrentUserRental(Integer pageNumber, Integer pageSize, String sortBy, String sortDir) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(userRentalService.listOfUserRentals(pageNumber, pageSize, sortBy, sortDir));
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body( new MessageResponse(e.getMessage()));
        }
        catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new MessageResponse(e.getMessage()));
        }
    }
}
