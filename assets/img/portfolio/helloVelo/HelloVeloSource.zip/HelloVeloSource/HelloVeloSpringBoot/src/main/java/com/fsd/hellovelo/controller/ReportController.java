package com.fsd.hellovelo.controller;

import com.fsd.hellovelo.entity.Report;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.response.MessageResponse;
import com.fsd.hellovelo.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/api/admin/reports")
public class ReportController {

    private final ReportService reportService;

    @Autowired
    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping
    public ResponseEntity<?> findAllReports() {
        try {
            List<Report> reports = reportService.findAllReports();
            return ResponseEntity.status(HttpStatus.OK).body(reports);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @DeleteMapping("{reportId}")
    public ResponseEntity<?> deleteReport(@PathVariable("reportId") Long reportId) {
        try {
            reportService.deleteReport(reportId);
            return ResponseEntity.status(HttpStatus.OK).body(new MessageResponse("Report deleted with id: " + reportId ));
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

    @GetMapping("{reportId}")
    public ResponseEntity<?> getReport(@PathVariable("reportId") Long reportId) {
        try {
                Report report = reportService.getReport(reportId);
                return ResponseEntity.status(HttpStatus.OK).body(report);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse(e.getMessage()));
        }
    }

}
