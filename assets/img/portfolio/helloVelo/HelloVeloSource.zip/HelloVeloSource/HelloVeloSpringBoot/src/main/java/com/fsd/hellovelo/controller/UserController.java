package com.fsd.hellovelo.controller;


import com.fsd.hellovelo.entity.User;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.payload.request.UpdateUserRequest;
import com.fsd.hellovelo.payload.request.UserStatus;
import com.fsd.hellovelo.service.AdminUserService;
import com.fsd.hellovelo.service.StripeService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/api/admin/user")
public class UserController {

    private AdminUserService adminUserService;
    private StripeService stripeService;

    @Autowired
    public UserController(AdminUserService adminUserService, StripeService stripeService){
        this.adminUserService = adminUserService;
        this.stripeService = stripeService;
    }

    @GetMapping("/")
    public ResponseEntity<?> getAllUsers() {
        try {
            List<User> users =  adminUserService.getUsers();
            return ResponseEntity.status(HttpStatus.OK).body(users);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/activeUsers")
    public ResponseEntity<?> getActiveUsers() {
        try {
            List<User> users =  adminUserService.getActiveUsers();
            return ResponseEntity.status(HttpStatus.OK).body(users);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping(path = "{id}")
    public ResponseEntity<?> getUser(@PathVariable("id") Long id) {
        try {
            User user =  adminUserService.getUser(id);
            return ResponseEntity.status(HttpStatus.OK).body(user);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PutMapping("/")
    public ResponseEntity<?> updateUser(@RequestBody UpdateUserRequest updateUser) {
        try {
            adminUserService.updateUser(updateUser);
            if(updateUser.hasRole("admin")){
                System.out.println(updateUser.hasRole("admin"));
                System.out.println(updateUser.getRole());
                stripeService.deleteSubscription(updateUser.getId());
            }
            return ResponseEntity.status(HttpStatus.OK).body(updateUser.getUsername());
        }
        catch(NoSuchElementException e){
            return ResponseEntity.status(HttpStatus.OK).body(String.format("User %s has no subscriptions", updateUser.getUsername()));
        }
        catch (ResourceNotFoundException | IllegalArgumentException | StripeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PatchMapping("/status/{id}")
    public ResponseEntity<?> updateUserStatus(@RequestBody UserStatus userStatus, @PathVariable Long id) {
        try {
            adminUserService.updateStatus(id, userStatus);
            return ResponseEntity.status(HttpStatus.OK).body(id);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @DeleteMapping(path = "{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            adminUserService.deleteUser(id);
            return ResponseEntity.status(HttpStatus.OK).body(id);
        }
        catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
