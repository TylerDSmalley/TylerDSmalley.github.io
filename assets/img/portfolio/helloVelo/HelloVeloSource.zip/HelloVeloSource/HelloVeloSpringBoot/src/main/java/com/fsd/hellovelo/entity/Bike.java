package com.fsd.hellovelo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "bikes")
public class Bike {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    @NotNull
    @Pattern(regexp="^[A-Z]{2}[0-9]{8}$", message="Serial number must contain 2 uppercase chars and 8 digits ")
    private String serialNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate lastMaintenance= LocalDate.now();

    @Column(nullable = false)
    @NotNull
    private boolean currentlyInUse= false;

//    public boolean getIsCurrentlyInUse() {
//        return currentlyInUse;
//    }
//    public void setIsCurrentlyInUse(boolean newCurrentlyInUse) {
//        currentlyInUse = newCurrentlyInUse;
//    }

    @Enumerated(EnumType.STRING)
    @NotNull
    private  BikeType bikeType;


//    @ManyToOne(cascade = CascadeType.MERGE) // fetch = FetchType.LAZY,
    @ToString.Exclude
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @Valid
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "station_id", referencedColumnName = "id")
    private Station station;


    public enum BikeType {
        ELECTRIC,
        STANDARD
    }

    private EStatus status = EStatus.ACTIVE;

}
