package com.fsd.hellovelo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(	name = "coupons")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Min(1)
    @Max(100)
    private BigDecimal percentOff;

    //this is amount in cents - $1 would be 100 here
    @Min(1)
    private Long amountOff;

    private EStatus status = EStatus.ACTIVE;

    private ECouponStatus visibility = ECouponStatus.VISIBLE;

    private String stripeCouponId;

    private LocalDate expirationDate;

    private String title;
}
