package com.fsd.hellovelo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(	name = "discounts")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Discount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne()
    private Subscription subscription;

    @ManyToOne()
    private User user;

    private String stripePromoCodeId;

    private boolean applied;

    private LocalDate appliedDate;

    private String promoCode;

    @ManyToOne()
    private Coupon coupon;

    public Discount(String stripeDiscountId, boolean applied, LocalDate appliedDate, Coupon coupon, String promoCode) {
        this.stripePromoCodeId = stripeDiscountId;
        this.applied = applied;
        this.appliedDate = appliedDate;
        this.coupon = coupon;
        this.promoCode = promoCode;
    }

    public Discount(Subscription subscription, User user, String stripeDiscountId, boolean applied, LocalDate appliedDate, Coupon coupon, String promoCode) {
        this.subscription = subscription;
        this.user = user;
        this.stripePromoCodeId = stripeDiscountId;
        this.applied = applied;
        this.appliedDate = appliedDate;
        this.coupon = coupon;
        this.promoCode = promoCode;
    }

}
