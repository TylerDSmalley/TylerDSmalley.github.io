package com.fsd.hellovelo.entity;

public enum ECouponStatus {
    HIDDEN,
    VISIBLE
}
