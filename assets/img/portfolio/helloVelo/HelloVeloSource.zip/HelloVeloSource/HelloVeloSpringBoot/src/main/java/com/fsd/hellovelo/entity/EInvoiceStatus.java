package com.fsd.hellovelo.entity;

public enum EInvoiceStatus {
    NOT_CREATED,
    CREATED,
    PAID
}
