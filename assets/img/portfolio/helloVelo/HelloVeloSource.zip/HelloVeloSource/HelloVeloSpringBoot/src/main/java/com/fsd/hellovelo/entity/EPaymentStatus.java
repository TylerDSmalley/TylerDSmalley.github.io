package com.fsd.hellovelo.entity;

public enum EPaymentStatus {
    FAILED,
    PENDING,
    CONFIRMED,
    CANCELED
}
