package com.fsd.hellovelo.entity;

public enum EStatus {
    ACTIVE,
    DISABLED,
    InMAINTENANCE,
}
