package com.fsd.hellovelo.entity;

public enum EType {
    BIKE,
    OTHER
}
