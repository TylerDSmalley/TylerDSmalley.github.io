package com.fsd.hellovelo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "invoices")
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne
    private Subscription subscription;

    @NotNull
    @ManyToOne
    private User user;

    private BigDecimal paymentPrice;

    private LocalDate dateCreated;

    private LocalDate dateDue;

    private EPaymentStatus paymentStatus;

    private String invoicePdfUrl;

    private String stripeInvoiceId;

    private long rentalDiscountSum = 0;

    private long overageSum = 0;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(	name = "invoice_discounts",
            joinColumns = @JoinColumn(name = "invoice_id"),
            inverseJoinColumns = @JoinColumn(name = "discount_id"))
    private List<Discount> appliedDiscounts = new ArrayList<>();

    private EInvoiceStatus invoiceStatus = EInvoiceStatus.NOT_CREATED;

    public Invoice(User user, LocalDate dateCreated, EPaymentStatus paymentStatus, EInvoiceStatus invoiceStatus) {
        this.user = user;
        this.dateCreated = dateCreated;
        this.paymentStatus = paymentStatus;
        this.invoiceStatus = invoiceStatus;
    }
}
