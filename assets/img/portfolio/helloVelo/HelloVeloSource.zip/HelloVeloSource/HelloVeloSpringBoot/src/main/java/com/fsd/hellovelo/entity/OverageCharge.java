package com.fsd.hellovelo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(	name = "overageCharges")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OverageCharge {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @OneToOne
    private Rental rental;

    @NotNull
    @ManyToOne
    private User user;

    @ManyToOne
    private Invoice invoice = null;

    @NotNull
    private Long minutesOver;

    public OverageCharge(Rental rental, User user, Long minutesOver) {
        this.rental = rental;
        this.user = user;
        this.minutesOver = minutesOver;
    }

    public OverageCharge(Rental rental, User user, Long minutesOver, Invoice invoice) {
        this.rental = rental;
        this.user = user;
        this.minutesOver = minutesOver;
        this.invoice = invoice;
    }
}
