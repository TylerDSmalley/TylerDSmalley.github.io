package com.fsd.hellovelo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(	name = "referrals")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Referral {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne()
    private User referringUser;

    @NotNull
    private String referralEmail;

    @ManyToOne()
    private Discount referringDiscount;

    @ManyToOne()
    private Discount referredDiscount;

    private String promoCode;

    public Referral(User referringUser, String referralEmail, Discount referredDiscount, Discount referringDiscount, String promoCode) {
        this.referringUser = referringUser;
        this.referralEmail = referralEmail;
        this.referredDiscount = referredDiscount;
        this.referringDiscount = referringDiscount;
        this.promoCode = promoCode;

    }
}
