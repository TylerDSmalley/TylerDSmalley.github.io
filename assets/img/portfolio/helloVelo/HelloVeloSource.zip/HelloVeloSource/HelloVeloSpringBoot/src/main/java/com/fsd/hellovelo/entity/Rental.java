package com.fsd.hellovelo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(	name = "rentals")
public class Rental {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @JsonFormat(pattern = "yyyy-MMMM-dd hh:mm:ss")
    private LocalDateTime startTime;

    @JsonFormat(pattern = "yyyy-MMMM-dd hh:mm:ss")
    private LocalDateTime endTime;

    @NotNull
    @ManyToOne
    private User user;

    @NotNull
    @ManyToOne
    private Bike bike;

    @NotNull
    @ManyToOne
    @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
    private Station startStation;

    @ManyToOne
    @JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
    private Station endStation;

    //@OneToOne
    @Transient
    private Long overageMinutes;
    //private OverageCharge overageCharge;

    private boolean discountedStartStation = false;

    //in cents
    private Long discountEarned;

    public Long getId() {
        return id;
    }



    public Rental() {
    }

    public Rental(LocalDateTime startTime, User user, Bike bike, Station startStation) {
        this.startTime = startTime;
        this.user = user;
        this.bike = bike;
        this.startStation = startStation;
    }

    public Long getDiscountEarned() {
        return discountEarned;
    }

    public void setDiscountEarned(Long discountEarned) {
        this.discountEarned = discountEarned;
    }

    public boolean isDiscountedStartStation() {
        return discountedStartStation;
    }

    public void setDiscountedStartStation(boolean discountedStartStation) {
        this.discountedStartStation = discountedStartStation;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Bike getBike() {
        return bike;
    }

    public void setBike(Bike bike) {
        this.bike = bike;
    }

    public Station getStartStation() {
        return startStation;
    }

    public void setStartStation(Station startStation) {
        this.startStation = startStation;
    }

    public Station getEndStation() {
        return endStation;
    }

    public void setEndStation(Station endStation) {
        this.endStation = endStation;
    }

//    public OverageCharge getOverageCharge(){
//        return overageCharge;
//    }
//    public void SetOverageCharge(OverageCharge overageCharge){
//        this.overageCharge = overageCharge;
//    }

    public Long getOverageMinutes(){
        return overageMinutes;
    }
    public void setOverageMinutes(Long overageMinutes){
        this.overageMinutes = overageMinutes;
    }

    @Override
    public String toString() {
        return "Rental{" +
                "id=" + id +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", user=" + user +
                ", bike=" + bike +
                ", startStation=" + startStation +
                ", endStation=" + endStation +
                '}';
    }
}
