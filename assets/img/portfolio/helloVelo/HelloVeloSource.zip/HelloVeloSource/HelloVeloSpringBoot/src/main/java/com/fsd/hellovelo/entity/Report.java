package com.fsd.hellovelo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(	name = "reports")
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(min = 1, max = 1000, message = "Report body must be 1-1000 characters.")
    @Column(nullable = false, length = 1000)
    private String body;

    @NotNull
    @Column(nullable = false)
    @JsonFormat(pattern = "yyyy-MMMM-dd hh:mm:ss")
    private LocalDateTime reportTime = LocalDateTime.now();

    @NotNull
    @ManyToOne()
    @JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
    private User user;


    @ManyToOne()
    @JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
    private Bike bike;


    @ManyToOne
    @JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
    private Station station;

    private String imageURL;



}
