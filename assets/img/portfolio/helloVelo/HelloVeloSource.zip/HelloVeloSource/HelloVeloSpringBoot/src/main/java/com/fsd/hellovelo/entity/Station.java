package com.fsd.hellovelo.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "station")
public class Station {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100, unique = true)
    @NotNull
    @Size(min = 1, max = 100, message = "Station name must be 1-100 characters long")
    private String name;

//    @Pattern(regexp="[0-9]", message = "The value must only contain digits.")
    //@Digits(integer=6, fraction=0, message="you must enter a number")
    @Max(value = 1000, message = "Number of slots cannot exceed 100")
    @Min(value = 0,  message = "Number of slots cannot be negative")
    @Column(nullable = false)
    private int totalSlots;

    // make latitude and longitude doubles (max 90 and max 180)?
    @Pattern(regexp="-?[0-9]\\d*(\\.\\d+)?$", message = "The latitude must only contain digits.")
    @Column(nullable = false)
    @NotNull
    @Size(min = 1, max = 100, message = "Latitude must be 1-100 characters long")
    private String latitude;

    @Pattern(regexp="-?[0-9]\\d*(\\.\\d+)?$", message = "The longitude must only contain digits.")
    @Column(nullable = false)
    @NotNull
    @Size(min = 1, max = 100, message = "Longitude must be 1-100 characters long")
    private String longitude;

    @Transient
    private Long availableSlots;

    @Transient
    private Long numberOfBikes;

    @Transient
    @JsonIgnoreProperties(value = {"station"})
    private List<Bike> bikes;

//    @OneToMany(cascade = CascadeType.ALL)
//    @OneToMany(fetch = FetchType.LAZY)
//    @JoinColumn( name = "station_id", referencedColumnName = "id")
//    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})


//    @OneToMany(mappedBy = "station")//orphanRemoval = true  //, cascade = CascadeType.ALL
//    private List<Bike> bikes; //= new ArrayList<>();
//    private Set<Bike> bikes;

    private EStatus status = EStatus.ACTIVE;
}
