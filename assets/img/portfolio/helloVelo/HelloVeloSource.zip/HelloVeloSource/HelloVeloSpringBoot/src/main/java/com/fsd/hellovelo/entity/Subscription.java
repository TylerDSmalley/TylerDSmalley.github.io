package com.fsd.hellovelo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//import javax.persistence.*;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "subscriptions")
public class Subscription {

    public Subscription(LocalDate startDate, EPaymentStatus status, String stripeSubscriptionId, BigDecimal price, LocalDate nextPaymentDate, String paymentLast4, String paymentMethodId, User user) {
        this.startDate = startDate;
        this.status = status;
        this.stripeSubscriptionId = stripeSubscriptionId;
        this.price = price;
        this.nextPaymentDate = nextPaymentDate;
        this.paymentLast4 = paymentLast4;
        this.paymentMethodId = paymentMethodId;
        this.user = user;
    }


    public Subscription(LocalDate startDate, EPaymentStatus status, LocalDate nextPaymentDate, String paymentLast4, String paymentMethodId, User user) {
        this.startDate = startDate;
        this.status = status;
        this.nextPaymentDate = nextPaymentDate;
        this.paymentLast4 = paymentLast4;
        this.paymentMethodId = paymentMethodId;
        this.user = user;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private LocalDate startDate = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private EPaymentStatus status;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private EType type = EType.BIKE;

    private String stripeSubscriptionId;

    private String stripeOverageItemId;

    private BigDecimal price;

    private LocalDate nextPaymentDate;

    private String paymentLast4;

    private String paymentMethodId;

    @Transient
    private String invoicePdfLink;

    @NotNull
    @ManyToOne
    private User user;

    public String getInvoicePdfLink() {
        return invoicePdfLink;
    }

    public void setInvoicePdfLink(String invoicePdfLink) {
        this.invoicePdfLink = invoicePdfLink;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public EPaymentStatus getStatus() {
        return status;
    }

    public void setStatus(EPaymentStatus status) {
        this.status = status;
    }

    public String getStripeSubscriptionId() {
        return stripeSubscriptionId;
    }

    public void setStripeSubscriptionId(String stripeSubscriptionId) {
        this.stripeSubscriptionId = stripeSubscriptionId;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public LocalDate getNextPaymentDate() {
        return nextPaymentDate;
    }

    public void setNextPaymentDate(LocalDate nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    public String getPaymentLast4() {
        return paymentLast4;
    }

    public void setPaymentLast4(String paymentLast4) {
        this.paymentLast4 = paymentLast4;
    }

    public String getPaymentMethodId() {
        return paymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public EType getType() {
        return type;
    }

    public void setType(EType type) {
        this.type = type;
    }

    public String getStripeOverageItemId() {
        return stripeOverageItemId;
    }

    public void setStripeOverageItemId(String stripeOverageItemId) {
        this.stripeOverageItemId = stripeOverageItemId;
    }
}
