package com.fsd.hellovelo.payload.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

public class BikeTransferRequest {

    @NotNull
    private List<Long> checkboxOptions;

    @NotNull
    private Long transferStation;

    public List<Long> getCheckboxOptions() {
        return checkboxOptions;
    }

    public void setCheckboxOptions(List<Long> checkboxOptions) {
        this.checkboxOptions = checkboxOptions;
    }

    public Long getTransferStation() {
        return transferStation;
    }

    public void setTransferStation(Long transferStation) {
        this.transferStation = transferStation;
    }
}
