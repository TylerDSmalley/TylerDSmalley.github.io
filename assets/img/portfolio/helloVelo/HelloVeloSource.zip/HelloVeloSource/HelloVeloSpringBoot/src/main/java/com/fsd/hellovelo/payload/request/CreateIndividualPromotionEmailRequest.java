package com.fsd.hellovelo.payload.request;

import com.fsd.hellovelo.entity.Coupon;
import com.fsd.hellovelo.entity.User;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class CreateIndividualPromotionEmailRequest {
    @NotNull
    private List<Long> customerIds;

    @NotNull
    private Long couponId;

    @NotNull
    private LocalDate expiresAt;

//    Maximum number of times this promotion code can be redeemed.
    private int max_redemptions;

    public int getMax_redemptions() {
        return max_redemptions;
    }

    public void setMax_redemptions(int max_redemptions) {
        this.max_redemptions = max_redemptions;
    }

    public List<Long> getCustomerIds() {
        return customerIds;
    }

    public void setCustomerIds(List<Long> customerIds) {
        this.customerIds = customerIds;
    }

    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public LocalDate getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDate expiresAt) {
        this.expiresAt = expiresAt;
    }
}
