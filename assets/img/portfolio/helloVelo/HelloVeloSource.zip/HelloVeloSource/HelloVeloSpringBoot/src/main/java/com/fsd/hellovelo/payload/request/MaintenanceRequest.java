package com.fsd.hellovelo.payload.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Report;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class MaintenanceRequest {

    private Long id;


    private LocalDate maintenanceDate= LocalDate.now();


    private Long maintainedBikeId;


    private Long reportId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getMaintenanceDate() {
        return maintenanceDate;
    }

    public void setStartTime(LocalDate maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }
}
