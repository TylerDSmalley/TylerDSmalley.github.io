package com.fsd.hellovelo.payload.request;

import lombok.Data;

@Data
public class PostalCodeRequest {

    public String postalCode;
}
