package com.fsd.hellovelo.payload.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.EStatus;
import com.fsd.hellovelo.entity.Station;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateBikeRequest {

    private Long id;


    @NotNull
    @Pattern(regexp="^[A-Z]{2}[0-9]{8}$", message="Serial number must contain 2 uppercase chars and 8 digits ")
    private String serialNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate lastMaintenance= LocalDate.now();

    @NotNull
    private boolean currentlyInUse= false;


    @Enumerated(EnumType.STRING)
    @NotNull
    private Bike.BikeType bikeType;


    private Long stationId;

    public enum BikeType {
        ELECTRIC,
        STANDARD
    }

    private EStatus status = EStatus.ACTIVE;
}
