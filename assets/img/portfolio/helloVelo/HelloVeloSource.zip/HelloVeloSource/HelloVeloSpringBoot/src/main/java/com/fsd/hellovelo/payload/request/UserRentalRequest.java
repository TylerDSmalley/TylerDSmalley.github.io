package com.fsd.hellovelo.payload.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class UserRentalRequest {

    @NotNull
    @Pattern(regexp="^[A-Z]{2}[0-9]{8}$", message="Serial number must contain 2 uppercase chars and 8 digits ")
    private String serialNumber;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
