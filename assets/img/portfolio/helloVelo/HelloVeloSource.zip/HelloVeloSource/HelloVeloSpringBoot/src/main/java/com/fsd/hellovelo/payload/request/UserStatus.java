package com.fsd.hellovelo.payload.request;

import javax.validation.constraints.NotBlank;

public class UserStatus {
    @NotBlank
    public String status;
}
