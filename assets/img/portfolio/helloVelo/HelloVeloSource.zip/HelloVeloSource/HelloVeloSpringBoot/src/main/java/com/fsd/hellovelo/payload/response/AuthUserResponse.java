package com.fsd.hellovelo.payload.response;

import com.fsd.hellovelo.entity.Role;
import com.fsd.hellovelo.entity.User;

import java.util.Set;

public class AuthUserResponse{
    private String email;
    private String username;
    private Long id;
    private Set<Role> roles;
    private boolean provisionAccess;

    public AuthUserResponse(String email, String username, Long id, Set<Role> roles, boolean provisionAccess) {
        this.email = email;
        this.username = username;
        this.id = id;
        this.roles = roles;
        this.provisionAccess = provisionAccess;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public boolean isProvisionAccess() {
        return provisionAccess;
    }

    public void setProvisionAccess(boolean provisionAccess) {
        this.provisionAccess = provisionAccess;
    }
}
