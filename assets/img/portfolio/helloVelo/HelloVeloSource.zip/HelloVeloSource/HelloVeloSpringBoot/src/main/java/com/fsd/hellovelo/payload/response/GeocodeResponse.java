package com.fsd.hellovelo.payload.response;

import lombok.Data;

import java.util.ArrayList;

@Data
public class GeocodeResponse {

    public Info info;
    public Options options;
    public ArrayList<Result> results;

    public static class Copyright{
        public String text;
        public String imageUrl;
        public String imageAltText;
    }

    public static class Info{
        public int statuscode;
        public Copyright copyright;
        public ArrayList<Object> messages;
    }

    public static class Options{
        public int maxResults;
        public boolean thumbMaps;
        public boolean ignoreLatLngInput;
    }

    public static  class ProvidedLocation{
        public String location;
    }

    public static class LatLng{
        public double lat;
        public double lng;
    }

    public static class DisplayLatLng{
        public double lat;
        public double lng;
    }

    public static class Location{
        public String street;
        public String adminArea6;
        public String adminArea6Type;
        public String adminArea5;
        public String adminArea5Type;
        public String adminArea4;
        public String adminArea4Type;
        public String adminArea3;
        public String adminArea3Type;
        public String adminArea1;
        public String adminArea1Type;
        public String postalCode;
        public String geocodeQualityCode;
        public String geocodeQuality;
        public boolean dragPoint;
        public String sideOfStreet;
        public String linkId;
        public String unknownInput;
        public String type;
        public LatLng latLng;
        public DisplayLatLng displayLatLng;
        public String mapUrl;
    }

    public static class Result{
        public ProvidedLocation providedLocation;
        public ArrayList<Location> locations;
    }
}
