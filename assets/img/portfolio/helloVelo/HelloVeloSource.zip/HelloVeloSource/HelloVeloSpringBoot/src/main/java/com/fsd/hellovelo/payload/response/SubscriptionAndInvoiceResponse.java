package com.fsd.hellovelo.payload.response;

import lombok.Data;

import java.util.List;

@Data
public class SubscriptionAndInvoiceResponse {

    private String basePrice;

    private String overagePrice;

    private String currentEstimate;

    private List<String> appliedPromos;

    private long overageMinutes;

    private String overageFees;

    private String rentalStationDiscounts;

    private List<String> previousInvoicePdfLink;

    private String message;
}
