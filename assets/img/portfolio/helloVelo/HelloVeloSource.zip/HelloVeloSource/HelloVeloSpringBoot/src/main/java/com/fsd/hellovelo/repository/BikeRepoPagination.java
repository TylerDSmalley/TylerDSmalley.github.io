package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.EStatus;
import com.fsd.hellovelo.entity.Rental;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BikeRepoPagination extends PagingAndSortingRepository<Bike, Long> {


    Page<Bike> findAllByStatusIs(EStatus status, Pageable pageable);

    Page<Bike> findAllByStatusIsNot(EStatus status, Pageable pageable);


    @Query("SELECT b FROM Bike b LEFT JOIN b.station s WHERE b.status <> com.fsd.hellovelo.entity.EStatus.DISABLED" +
            " AND CONCAT(b.serialNumber, ' ', b.bikeType) " +
            " LIKE %:searchText% OR s.name LIKE %:searchText%")
    Page<Bike> findAll( Pageable pageable, @Param("searchText") String searchText);

//    @Query("SELECT b FROM Bike b WHERE b.status = com.fsd.hellovelo.entity.EStatus.ACTIVE AND CONCAT(b.station.name) " +
//            " LIKE %:searchText%")
//    Page<Bike> findAll( Pageable pageable, @Param("searchText") String searchText);
}
