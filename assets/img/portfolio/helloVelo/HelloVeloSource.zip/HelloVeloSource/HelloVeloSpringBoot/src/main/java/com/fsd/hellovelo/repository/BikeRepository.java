package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.EStatus;
import com.fsd.hellovelo.entity.Station;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface BikeRepository extends JpaRepository<Bike, Long> {

    Optional<Bike> findBySerialNumber(String serialNumber);

    //Optional<Bike> findByStationAndStationName(Station Station, String stationName);

    List<Bike> findBikesByStatusIsAndCurrentlyInUseIsFalse(EStatus status);
    List<Bike> findBikesByCurrentlyInUseIsFalseAndStatusIsAndStationIsNot(EStatus status, Station station);

    List<Bike> findAllByStatusIs(EStatus status);

    List<Bike> findAllByStatusIsNot(EStatus status);

    //List<Bike> findAllByStationIsNull();

    Long countAllByStation(Station station);

    List<Bike> findAllByStationId(Long stationId);

    List<Bike> findAllByStationIdAndCurrentlyInUseIsFalse(Long stationId);

    List<Bike> findAllByStationIdAndCurrentlyInUseIsFalseAndStatusIs(Long stationId, EStatus status);

    List<Bike> findByIdIn(List<Long> bikeIds);

    boolean existsByStation_Id(Long id);

    Optional<Bike> findBySerialNumberAndStatusIs(String serialNumber, EStatus status);



}
