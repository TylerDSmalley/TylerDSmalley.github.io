package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Discount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DiscountRepository extends JpaRepository<Discount, Long> {

    Optional<Discount> findByStripePromoCodeId(String stripePromoCodeId);

    Optional<Discount> findByPromoCode(String promoCode);
}
