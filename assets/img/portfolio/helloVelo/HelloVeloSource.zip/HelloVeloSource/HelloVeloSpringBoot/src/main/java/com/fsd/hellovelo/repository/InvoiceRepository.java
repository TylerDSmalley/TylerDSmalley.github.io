package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.*;
import org.apache.tomcat.jni.Local;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    Optional<Invoice> findBySubscriptionAndInvoiceStatusAndUserAndDateDueAfter(Subscription subscription, EInvoiceStatus eInvoiceStatus, User user, LocalDate afterDueDate);
    Optional<Invoice> findBySubscriptionAndInvoiceStatus(Subscription subscription, EInvoiceStatus invoiceStatus);
    Optional<Invoice> findBySubscriptionAndInvoiceStatusNot(Subscription subscription, EInvoiceStatus invoiceStatus);
    Optional<Invoice> findByStripeInvoiceId(String stripeInvoiceId);

    List<Invoice> findBySubscriptionAndInvoiceStatusOrderByDateDue(Subscription subscription, EInvoiceStatus eInvoiceStatus);

    Optional<Invoice> findFirstBySubscriptionAndInvoiceStatusOrderByIdDesc(Subscription subscription, EInvoiceStatus paid);
}
