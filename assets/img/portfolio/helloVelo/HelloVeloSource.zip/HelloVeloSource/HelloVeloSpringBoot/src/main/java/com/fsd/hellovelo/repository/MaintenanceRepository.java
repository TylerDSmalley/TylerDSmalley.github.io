package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Maintenance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MaintenanceRepository extends JpaRepository<Maintenance, Long> {

    @Override
    Optional<Maintenance> findById(Long aLong);

}
