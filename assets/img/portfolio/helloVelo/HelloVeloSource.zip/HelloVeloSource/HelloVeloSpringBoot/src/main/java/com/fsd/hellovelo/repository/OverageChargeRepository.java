package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.OverageCharge;
import com.fsd.hellovelo.entity.Rental;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OverageChargeRepository extends JpaRepository<OverageCharge, Long> {


    OverageCharge findByRentalId(Long rentalId);


}
