package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Discount;
import com.fsd.hellovelo.entity.Referral;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ReferralRepository extends JpaRepository<Referral, Long> {

    Optional<Referral> findFirstByReferredDiscount(Discount referredDiscount);

    Optional<Referral> findFirstByPromoCode(String promoCode);
}
