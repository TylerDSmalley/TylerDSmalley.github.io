package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Rental;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface RentalRepoPagination extends PagingAndSortingRepository<Rental, Long>{

    Page<Rental> findAll(Pageable pageable);

//    ("SELECT r from Rental r WHERE r.user.username =: searchText OR r.bike.serialNumber =: searchText OR " +
//            "r.startStation.name =: searchText OR r.endStation.name =: searchText")

    @Query("SELECT r FROM Rental r JOIN r.startStation ss JOIN r.endStation es JOIN r.user u JOIN r.bike b WHERE CONCAT(ss.name, ' ', es.name, ' ', u.username, ' ', b.serialNumber) " +
            " LIKE %:searchText% ")
    Page<Rental> findAll(Pageable pageable, @Param("searchText") String searchText);

}
