package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Rental;
import com.fsd.hellovelo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface RentalRepository extends JpaRepository<Rental, Long> {
    Optional<Rental> findFirstByEndStationNullAndUserEquals(User user);

    Optional<Rental> findFirstByEndStationNullOrEndTimeNullAndUserEqualsAndBikeEquals(User user, Bike bike);

    @Query("SELECT r from Rental r WHERE r.user = ?1 AND (r.endStation IS NULL OR r.endTime IS NULL)")
    Optional<Rental> findTopByEndStationNullOrEndTimeNullAndUserEquals(User user);

    List<Rental> findAllByStartTimeIsAfterAndStartTimeIsBefore(LocalDateTime afterDate, LocalDateTime beforeDate);



//    @Query("SELECT COUNT(r) from Rental r WHERE WEEKDAY(r.startTime) = ?1")

}
