package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.EStatus;
import com.fsd.hellovelo.entity.Station;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StationRepository extends JpaRepository<Station, Long> {

    Optional<Station> findStationByName(String name);

    Station findByName(String name);

    Optional<Station> findStationByLatitudeAndLongitude(String latitude, String longitude);

    List<Station> findStationsByStatusIs(EStatus status);

    List<Station> findStationsByStatusIsAndIdIsNot(EStatus status, Long stationId);

    Optional<Station> findByStatusIsAndIdIs(EStatus status, Long stationId);



}
