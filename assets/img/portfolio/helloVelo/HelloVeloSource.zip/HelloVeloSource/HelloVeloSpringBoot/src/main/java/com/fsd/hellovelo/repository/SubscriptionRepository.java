package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    Optional<Subscription> findByStripeSubscriptionId(String subscriptionId);

    Optional<Subscription> findFirstByUserAndTypeEqualsAndStatusNot(User user, EType type, EPaymentStatus ePaymentStatus);

    Optional<Subscription> findFirstByUserAndTypeEqualsAndStatus(User user, EType bike, EPaymentStatus canceled);
}
