package com.fsd.hellovelo.repository;

import com.fsd.hellovelo.entity.Bike;
import com.fsd.hellovelo.entity.Rental;
import com.fsd.hellovelo.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

public interface UserRentalRepoPagination extends PagingAndSortingRepository<Rental,Long> {

    //Page<Rental> findFirstByEndStationNullAndUserEquals(User user, Pageable pageable);

    //Page<Rental> findFirstByEndStationNullOrEndTimeNullAndUserEqualsAndBikeEquals(User user, Bike bike, Pageable pageable);

    Page<Rental> findAllByUserEquals(User user, Pageable pageable);

    //@Query("SELECT r from Rental r WHERE r.user = ?1 AND (r.endStation IS NULL OR r.endTime IS NULL)")
    //Page<Rental> findTopByEndStationNullOrEndTimeNullAndUserEquals(User user);
}
