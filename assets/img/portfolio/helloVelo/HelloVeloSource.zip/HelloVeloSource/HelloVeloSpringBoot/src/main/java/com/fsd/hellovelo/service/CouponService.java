package com.fsd.hellovelo.service;

import com.fsd.hellovelo.entity.Coupon;
import com.fsd.hellovelo.entity.ECouponStatus;
import com.fsd.hellovelo.entity.EStatus;
import com.fsd.hellovelo.exceptions.ResourceNotFoundException;
import com.fsd.hellovelo.repository.CouponRepository;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.param.CouponCreateParams;
import com.stripe.param.CouponUpdateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CouponService {
    
    private final CouponRepository couponRepository;
    
    @Autowired
    public CouponService(CouponRepository couponRepository){
        this.couponRepository = couponRepository;
    }


    public void createCoupon(Coupon coupon) throws StripeException {

        couponValidation(coupon);

        Stripe.apiKey = "sk_test_51K6PnvAl7XnbPt50bAvU4L3nGTDI8nXn8a4nPhjTcbznNDfW3j7sBL1UqmL2x5yUVXygbNJ6o32Gg01juu76NkbJ00ereY9xEJ";

        CouponCreateParams params;
        if(coupon.getAmountOff() != null){
            params = new CouponCreateParams.Builder().setAmountOff(coupon.getAmountOff()).setCurrency("CAD").build();
        }else{
            params = new CouponCreateParams.Builder().setPercentOff(coupon.getPercentOff()).setCurrency("CAD").build();
        }

        com.stripe.model.Coupon stripeCoupon = com.stripe.model.Coupon.create(params);

        coupon.setStripeCouponId(stripeCoupon.getId());
        couponRepository.save(coupon);
    }

    public List<Coupon> getAllCoupons() {
        return couponRepository.findAll();
    }

    public Coupon getCoupon(Long id) {
        return couponRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Error: Coupon not found."));
    }


        //coupons on stripe cannot be edited, so there's no point for us to edit it
//    public void updateCoupon(Long id, Coupon coupon) {
//        Coupon existingCoupon = couponRepository.findById(id).orElseThrow(()-> new IllegalArgumentException("Error: Coupon with id " + id + " found."));
//
//        if(coupon.getExpirationDate() != null){
//            if(coupon.getExpirationDate().isBefore(LocalDate.now())){
//                throw new IllegalArgumentException("Error: Expiration date must be in the future.");
//            }
//            existingCoupon.setExpirationDate(coupon.getExpirationDate());
//            Stripe.apiKey = "sk_test_51K6PnvAl7XnbPt50bAvU4L3nGTDI8nXn8a4nPhjTcbznNDfW3j7sBL1UqmL2x5yUVXygbNJ6o32Gg01juu76NkbJ00ereY9xEJ";
//            CouponUpdateParams params = CouponUpdateParams.builder()..build();
//        }
//        if(coupon.getStatus() != null){
//            existingCoupon.setStatus(coupon.getStatus());
//        }
//        couponRepository.save(existingCoupon);
//    }

    public void deleteCoupon(Long id) throws StripeException {
        Coupon coupon = couponRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Error: Could not find coupon."));
        coupon.setStatus(EStatus.DISABLED);
        couponRepository.save(coupon);

        Stripe.apiKey = "sk_test_51K6PnvAl7XnbPt50bAvU4L3nGTDI8nXn8a4nPhjTcbznNDfW3j7sBL1UqmL2x5yUVXygbNJ6o32Gg01juu76NkbJ00ereY9xEJ";
        com.stripe.model.Coupon stripeCoupon = com.stripe.model.Coupon.retrieve(coupon.getStripeCouponId());
        com.stripe.model.Coupon deletedCoupon = stripeCoupon.delete();
    }

    public void couponValidation(Coupon coupon){
        if((coupon.getAmountOff() == null && coupon.getPercentOff() == null) || (coupon.getAmountOff() != null && coupon.getPercentOff() != null)){
            throw new IllegalArgumentException("Error: Coupon must have either a percent off or an amount off.");
        }

        if(coupon.getExpirationDate() != null && coupon.getExpirationDate().isBefore(LocalDate.now())){
            throw new IllegalArgumentException("Error: Expiration date must be in the future.");
        }
    }


    public List<Coupon> getAllVisibleCoupons() {
        return couponRepository.findByVisibilityAndStatus(ECouponStatus.VISIBLE, EStatus.ACTIVE);
    }
}
