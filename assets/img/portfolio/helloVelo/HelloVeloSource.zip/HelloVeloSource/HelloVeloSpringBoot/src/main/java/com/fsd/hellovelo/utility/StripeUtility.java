package com.fsd.hellovelo.utility;

import com.stripe.exception.SignatureVerificationException;
import com.stripe.model.Event;
import com.stripe.model.EventDataObjectDeserializer;
import com.stripe.model.StripeObject;
import com.stripe.net.Webhook;

public class StripeUtility {

    public static Event getEvent(String json, String sigHeader, String secret) {
//        String endpointSecret = "${STRIPE_WEBHOOK_SECRET}";
        Event event = null;
        try {
            return Webhook.constructEvent(json, sigHeader, secret);
        } catch (SignatureVerificationException e) {
            // Invalid signature
            throw new IllegalArgumentException(json + "\n" + sigHeader + "\n" + secret);
        }
    }

    public static StripeObject getStripeObject(Event event){
        EventDataObjectDeserializer dataObjectDeserializer = event.getDataObjectDeserializer();
        StripeObject stripeObject = null;
        if (dataObjectDeserializer.getObject().isPresent()) {
            return dataObjectDeserializer.getObject().get();
        } else {
            throw new IllegalArgumentException();
        }
    }
}
