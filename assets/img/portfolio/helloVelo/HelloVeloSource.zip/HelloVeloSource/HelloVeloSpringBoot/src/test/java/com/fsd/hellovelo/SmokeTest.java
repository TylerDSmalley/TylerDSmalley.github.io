package com.fsd.hellovelo;

import com.fsd.hellovelo.controller.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
public class SmokeTest {

    @Autowired
    private AuthController authController;

    @Autowired
    private BikeController bikeController;

    @Autowired
    private StationController stationController;

    @Autowired
    private StationUserController stationUserController;

    @Autowired
    private TestController testController;

    @Autowired
    private UserController userController;

    @Test
    void contextLoads(){
        assertThat(authController).isNotNull();
        assertThat(bikeController).isNotNull();
        assertThat(stationController).isNotNull();
        assertThat(stationUserController).isNotNull();
        assertThat(testController).isNotNull();
        assertThat(userController).isNotNull();
    }
}
