import * as React from 'react';
import Button from '@mui/material/Button';
import CardMedia from '@mui/material/CardMedia';
import CssBaseline from '@mui/material/CssBaseline';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import axios from "axios";
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import { SearchBar } from "../components/SearchBar";

function Home() {

    const theme = createTheme();

    const [listOfBooks, setListOfBooks] = useState([]);
    let navigate = useNavigate();

    useEffect(() => {
        axios.get(
            `${process.env.REACT_APP_APIURL}/books`,
        ).then((response) => {
            setListOfBooks(response.data);
        });
    }, []);

    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <main className="w-100">
                <Container sx={{ minHeight: "fit-content" }} maxWidth="sm" className='contentBox rounded-3'>
                    <SearchBar placeholder={"Search Titles"} data={listOfBooks}></SearchBar>
                </Container>
                <Container sx={{ py: 8, my: 5, minHeight: "100vh" }} maxWidth="md" className='contentBox rounded-3'>
                    <Typography
                        component="h1"
                        variant="h2"
                        align="center"
                        color="text.primary"
                        gutterBottom
                    >
                        The Library
                    </Typography>
                    <Typography variant="h5" align="center" color="text.secondary" paragraph>
                        Browse our selection of books and start adding to your bookshelves!
                    </Typography>
                    <Stack
                        sx={{ pt: 4 }}
                        direction="row"
                        spacing={2}
                        justifyContent="center"
                    >
                    </Stack>
                    <Grid container spacing={4}>
                        {listOfBooks.map((value, key) => (
                            <Grid item key={key} xs={12} sm={6} md={4}>
                                <Button
                                    size="small"
                                    onClick={
                                        () => {
                                            navigate(`/books/byId/${value.id}`)
                                        }
                                    }
                                >
                                    <CardMedia
                                        component="img"
                                        sx={{
                                            px: 0,
                                            maxWidth: "75%"
                                        }}
                                        image={value.coverPhoto}
                                        alt="random"
                                    />
                                </Button>
                            </Grid>
                        ))}
                    </Grid>
                </Container>
            </main>
        </ThemeProvider>
    );
}

export default Home