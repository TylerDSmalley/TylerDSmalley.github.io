import React, { useContext, useEffect, useState } from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Rating from '@mui/material/Rating';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../helpers/AuthContext";
import { useParams } from "react-router-dom";

function Review() {
  const [bookObject, setBookObject] = useState({});
  const [personalRating, setPersonalRating] = useState(0);
  const [reviewObject, setReviewObject] = useState({});
  const [aggRating, setAggRating] = useState(0);
  const theme = createTheme();
  const { authState } = useContext(AuthContext)
  let { bookId, rowId, userId } = useParams();
  let navigate = useNavigate();
  const initialValues = {
    summary: ""
  }

  useEffect(() => {
    if (!localStorage.getItem("accessToken")) {
      navigate("/login");
    } else {
      axios.get(`${process.env.REACT_APP_APIURL}/books/byId/${bookId}`).then((response) => {
        setBookObject(response.data);
        setAggRating(response.data.rating);
      });

      axios.get(`${process.env.REACT_APP_APIURL}/shelves/row/${rowId}`).then((response) => {
        setPersonalRating(response.data.personalRating);
      });

      axios.get(`${process.env.REACT_APP_APIURL}/review/userreview/${userId}/${bookId}`).then((response) => {
        setReviewObject(response.data);
      });
    }
  }, []);

  const getInitialValues = () => {
    if (reviewObject) {
      initialValues = {
        summary: reviewObject.summary ? reviewObject.summary : ""
      }
    } else {
      initialValues = {
        summary: ""
      }
    }
  }

  const changeRating = (newRating) => {
    let data = { personalRating: newRating }

    //Adds new personal rating when clicked
    axios.put(`${process.env.REACT_APP_APIURL}/shelves/rate/${rowId}`, data, {
      headers: { accessToken: localStorage.getItem("accessToken") },
    }).then((response) => {
      setPersonalRating(parseInt(response.data));
      let checkAgg = parseInt(aggRating);
      if (checkAgg == 0) {
        saveAggRating(newRating);
      } else {
        calculateAggRating();
      }
    });
  };

  const calculateAggRating = () => {
    axios.get(`${process.env.REACT_APP_APIURL}/shelves/allratings/${bookId}`).then((response) => {
      let ratingsList = new Array(response.data)
      let ratingsCount = ratingsList[0].count;
      let ratingsTotal = 0;

      //NEED TO CHECK FOR MORE THAN ONE RECORD HERE

      ratingsList[0].rows.map((value) => (
        ratingsTotal = ratingsTotal + value.personalRating
      ))
      let newAggRating = ratingsTotal / ratingsCount;
      setAggRating(newAggRating)
      saveAggRating(newAggRating);
    });
  };

  const saveAggRating = (newAggRating) => {
    let data = { rating: newAggRating };
    axios.put(`${process.env.REACT_APP_APIURL}/books/ratingupdate/${bookId}`, data).then((response) => {
      setAggRating(response.data.rating)
    });
  };

  const validationSchema = Yup.object().shape({
    summary: Yup.string().required("You must input a review"),
  })

  const onSubmit = (data) => {
    data.BookId = bookId;
    data.UserId = authState.id
    axios.post("${process.env.REACT_APP_APIURL}/review", data, {
      headers: { accessToken: localStorage.getItem("accessToken") },
    }).then((response) => {
      navigate(`/shelves/${data.UserId}`);
    });
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <main className="w-100">
        <Container sx={{ py: 8, my: 5, minHeight: "100vh" }} maxWidth="sm">
          <Box
            sx={{
              p: 5,
              marginTop: 8,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
            }}
            className='contentBox rounded-3'
          >
            <Typography
              sx={{
                textTransform: 'capitalize',
                fontWeight: 'bold'
              }}
              component="h5"
              variant="h5"
              color="info.main"
              gutterBottom
            >
              {bookObject.title} &gt; review &gt; edit
            </Typography>
            <Grid
              spacing={2}
              container
              direction="row"
              rowSpacing={1}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              <Grid item xs={2} sm={2} md={2}>
                <CardMedia
                  className="rounded my-2"
                  component="img"
                  sx={{ boxShadow: 3 }}
                  image={bookObject.coverPhoto}
                  alt={bookObject.title}
                  title={bookObject.title}
                />
              </Grid>
              <Grid>
                <Stack className='mt-2 ms-2'>
                  <Typography variant="h6">
                    {bookObject.title}
                  </Typography>
                  <Typography align='left' variant="caption" color="text.secondary">
                    by {bookObject.author}
                  </Typography>
                  <Typography align='left' variant="caption" color="text.secondary">
                    My rating:
                  </Typography>
                  <Rating
                    sx={{ pl: 0, ml: 0 }}
                    name="personalRating"
                    value={personalRating}
                    onChange={(event, newValue) => {
                      changeRating(newValue);
                    }}
                  />
                </Stack>
              </Grid>
            </Grid>

            <Formik initialValues={getInitialValues} onSubmit={onSubmit} validationSchema={validationSchema} enableReinitialize={true}>
              <Form className='d-flex flex-column  mb-3 w-100 align-items-start'>
                <label>Review </label>
                <Field
                  rows="15"
                  className="mb-5 w-100 p-3"
                  as="textarea"
                  name="summary"
                  placeholder="Enter your review..."
                />
                <Button
                  sx={{ bgcolor: 'primary.main', color: 'text.primary' }}
                  type="submit"
                  className='w-25'>
                  submit
                </Button>
                <ErrorMessage name="summary" component="span" />
              </Form>
            </Formik>
          </Box>
        </Container>
      </main>
    </ThemeProvider>
  )
}

export default Review;
