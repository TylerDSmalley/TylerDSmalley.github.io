const config = {
    development: {
        username: process.env.DBUSER,
        password: process.env.DBPASS,
        database: "placeholder",
        host: "placeholder",
        dialect: "mysql"
    },
    test: {
        username: process.env.DBUSER,
        password: process.env.DBPASS,
        database: "placeholder",
        host: "localhost",
        dialect: "mysql"
    },
    production: {
        username: process.env.DBUSER,
        password: process.env.DBPASS,
        database: "placeholder",
        host: "placeholder",
        dialect: "mysql"
    }
}

module.exports = config;