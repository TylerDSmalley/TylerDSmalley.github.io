package com.example.items.config;


import com.example.items.entity.Employee;
import com.example.items.entity.Location;
import com.example.items.repository.EmployeeRepository;
import com.example.items.repository.LocationRepository;
import lombok.AllArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.List;

@Configuration
@AllArgsConstructor
public class DBDataConfig {

    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    @Bean
    CommandLineRunner addUsers(EmployeeRepository employeeRepo, LocationRepository locationRepo) {

        if(employeeRepo.findByEmail("manager@items.com") == null && locationRepo.findById(1L).isEmpty()) {

            String password = bCryptPasswordEncoder.encode("Password1");
            return args -> {
                Location HQ = new Location();
                HQ.setLocationName("HQ");
                HQ.setAddress("155 St Denis");
                HQ.setCity("Montreal");
                HQ.setProvince("QC");
                HQ.setPostalCode("H2L 3G5");

                locationRepo.saveAll(List.of(HQ));

                Employee admin = new Employee ();
                admin.setFirstName("Joe");
                admin.setLastName("Dirt");
                admin.setEmail("manager@items.com");
                admin.setPasscode(password);
                admin.setPhone("555-555-5555");
                admin.setBirthDate("1950-05-05");
                admin.setSalary(85.55);
                admin.setEmergencyContactPhone("555-555-5555");
                admin.setEmergencyContactName("Batman");
                admin.setDepartment(Employee.EmployeeDepartment.IT);
                admin.setPosition(Employee.EmployeePosition.SOFTWARE_DEVELOPER);
                admin.setRole(Employee.UserRole.MANAGER);
                admin.setLocation(HQ);

                employeeRepo.saveAll(
                        List.of(admin)
                );

            };
        }
        return args -> {};
    }


}