package com.example.items.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer {
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("index");
        registry.addViewController("/admin/register").setViewName("register");
        registry.addViewController("/admin/list/requests").setViewName("admin-list-requests");
        registry.addViewController("/admin/list/employees").setViewName("admin-list-employee");
        registry.addViewController("/admin/updateEmployee").setViewName("update-employee");
        registry.addViewController("/admin/list/locations").setViewName("admin-list-locations");
        registry.addViewController("/admin/addLocation").setViewName("add-location");
        registry.addViewController("/admin/updateLocation").setViewName("add-location");
        registry.addViewController("/admin/showUpdateForm").setViewName("add-request-form");
        registry.addViewController("/").setViewName("index");
        registry.addViewController("/login").setViewName("login");
        registry.addViewController("/request").setViewName("request");
        registry.addViewController("/addRequestForm").setViewName("add-request-form");
        registry.addViewController("/updateEmployee").setViewName("register");
        registry.addViewController("/updateEmployeeForm").setViewName("update-employee");
        registry.addViewController("/document").setViewName("document");
        registry.addViewController("/submitDocument").setViewName("add-document-form");
        registry.addViewController("/showDocumentForm").setViewName("add-document-form");
    }
}
