package com.example.items.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Transactional
@Table(name="document")
public class Document {
    @Id
    @Column(name = "doc_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="doc_name")
    private String docName;

    @Column(name="doc_type")
    private String docType;

    @Lob
    private byte[] data;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employeeID", nullable = false)
    private Employee employee;

    public Document(String docName, String docType, byte[] data, Employee employee) {
        this.docName = docName;
        this.docType = docType;
        this.data = data;
        this.employee = employee;
    }
}
