package com.example.items.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name="jobs")
public class Job {

    //ENUM
    public enum jobStatus {
        OPEN,
        FILLED;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="title")
    @NotNull
    @Size(min=5,message = "Title must be at least 5 characters")
    private String title;

    @Column(name="body")
    @NotNull
    @Size(min=5,message = "Body must be at least 5 characters")
    private String body;

    @Column(name = "creationTS") //
    @CreationTimestamp
    private LocalDate creationTS;

    @Column(name="status")
    private jobStatus status = jobStatus.OPEN;
}
