package com.example.items.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;

import static org.springframework.web.util.HtmlUtils.htmlEscape;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name="requests")
public class Request {

    //ENUM
    public enum RequestType {
        TIME_OFF,
        TRANSFER_REQUEST;
    }

    public enum RequestStatus {
        PENDING,
        APPROVED,
        DENIED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employeeID", nullable = false)
    private Employee employee;

    @Column(name="title")
    @NotNull
    @Size(min=5,message = "Title must be at least 5 characters")
    private String title;

    @Column(name="body")
    @NotNull
    @Size(min=5,message = "Body must be at least 5 characters")
    private String body;

    @Column(name="requestType")
    private RequestType requestType;

    @Column(name="status")
    private RequestStatus status = RequestStatus.PENDING;

    @Column(name = "creationTS") //
    @CreationTimestamp
    private LocalDate creationTS;

    /*
    public String getTitle() {
        return htmlEscape(this.title);
    }

    public void setTitle(String title) {
        this.title = htmlEscape(title);
    }

    public String getBody() {
        return htmlEscape(this.body);
    }

    public void setBody(String body) {
        this.body = htmlEscape(body);
    }

     */
}
