package com.example.items.repository;

import com.example.items.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface DocRepository extends JpaRepository<Document,Long> {

    @Query("select d from Document d where d.employee.id = :employeeId")
    List<Document> findAllByEmployeeId(Long employeeId);
}
