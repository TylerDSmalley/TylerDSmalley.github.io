package com.example.items.repository;

import com.example.items.entity.Employee;
import com.example.items.entity.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface RequestRepository extends JpaRepository<Request, Long> {



    @Query("select r from Request r where r.employee.id = :employeeId")
    List<Request> findAllByEmployeeId(Long employeeId);
}