package com.example.items.security;

import com.example.items.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private  BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private LoginService loginService;

    @Bean
    public UserDetailsService userDetailsService() {
        return loginService;
    }

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder);
        provider.setUserDetailsService(loginService);
        return provider;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(daoAuthenticationProvider());
    }


    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/login").permitAll()
                .antMatchers("/").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/updateEmployeeForm").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/updateEmployee").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/request").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/addRequestForm").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/saveRequest").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/showUpdateForm").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/updateEmployee").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/deleteRequest").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/document").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/submitDocument").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/showDocumentForm").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/saveDocument").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/download-file").hasAnyRole("EMPLOYEE", "MANAGER")
                .antMatchers("/admin/**").hasRole("MANAGER")
                .and()
                .exceptionHandling()
                    .accessDeniedPage("/forbidden")
                .and()
                    .formLogin()
                    .loginPage("/login")
                    .failureUrl("/login_err")
                    .defaultSuccessUrl("/")
                .and()
                    .logout()
                    .logoutUrl("/logout")
                    .logoutSuccessUrl("/");
    }

}

/*
import com.example.items.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private LoginService loginService;

    @Override
    protected void configure(HttpSecurity security) throws Exception
    {
        security.httpBasic().disable();
    }
    /*
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(daoAuthenticationProvider());
    }

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder);
        provider.setUserDetailsService(loginService);
        return provider;
    }

    public void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/admin/list/requests").authenticated()
                .and()
                .formLogin()
                .loginPage("/login")
                .failureUrl("/login-error")
                .defaultSuccessUrl("/")
                .and()
                .logout()
                .logoutUrl("/logout")
                .logoutSuccessUrl("/");  // FIXME: needs a flash message to confirm logout
    }

    /*
    @Override
    protected void configure(final HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/", "/list", "/register", "/saveUser").permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                    .loginPage("/login")
                    .failureUrl("/login-error")
                    .defaultSuccessUrl("/")
                    .permitAll()
                .and()
                    .logout()
                    .logoutUrl("/logout")
                    .logoutSuccessUrl("/") // FIXME: needs a flash message
                .permitAll();
    }
    @Bean
    @Override
    public UserDetailsService userDetailsService() {
        UserDetails user =
                User.withDefaultPasswordEncoder()
                        .username("user")
                        .password("password")
                        .roles("USER")
                        .build();

        return new InMemoryUserDetailsManager(user);
    }
}
*/