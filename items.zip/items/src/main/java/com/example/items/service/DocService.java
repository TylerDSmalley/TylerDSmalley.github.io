package com.example.items.service;

import com.example.items.entity.Document;
import com.example.items.entity.Employee;
import com.example.items.entity.Request;
import com.example.items.repository.DocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;

import javax.print.Doc;
import java.util.List;
import java.util.Optional;

@Service
public class DocService {

    @Autowired
    private DocRepository  docRepository;

    public List<Document> getAllDocumentsById(Long employeeId) {
        return docRepository.findAllByEmployeeId(employeeId);
    }

    @Transactional
    public void saveFile(MultipartFile file,Employee employee){
        String docName = file.getOriginalFilename();
        try{
            Document doc = new Document(docName,file.getContentType(),file.getBytes(),employee);
            docRepository.save(doc);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public Document getFile(Long fileId){
        return docRepository.findById(fileId).get();
    }

    public List<Document> getFiles(){return docRepository.findAll();}

    public Document findById(Long id){
        return docRepository.findById(id).get();
    }
}
