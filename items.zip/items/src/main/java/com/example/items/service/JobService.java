package com.example.items.service;

import com.example.items.entity.Job;
import com.example.items.entity.Location;
import com.example.items.repository.JobRepository;
import com.example.items.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Service
public class JobService {

    @Autowired
    private final JobRepository jobRepository;

    public JobService(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Job getJobById(@RequestParam Long jobId) {
        return jobRepository.findById(jobId).get();
    }

    public void saveJob(Job job){
        jobRepository.save(job);
    }

    public void deleteJob(@RequestParam Long jobId){ jobRepository.deleteById(jobId);}
}
