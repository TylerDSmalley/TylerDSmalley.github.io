package com.example.items.service;

import com.example.items.entity.Employee;
import com.example.items.entity.Location;
import com.example.items.entity.Request;
import com.example.items.repository.LocationRepository;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;

@Service
public class LocationService {

    private final LocationRepository locationRepo;

    public LocationService(LocationRepository locationRepo) {
        this.locationRepo = locationRepo;
    }

    public List<Location> getAllLocations() {
        return locationRepo.findAll();
    }

    public Location getLocationById(@RequestParam Long locationId) {
        return locationRepo.findById(locationId).get();
    }

    public void saveLocation(Location location){
        locationRepo.save(location);
    }

    public void deleteLocation(@RequestParam Long locationId){ locationRepo.deleteById(locationId);}

}
