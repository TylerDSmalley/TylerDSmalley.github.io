package com.example.items.service;

import com.example.items.entity.Employee;
import com.example.items.entity.Request;
import com.example.items.repository.RequestRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Service
public class RequestService {
    private final RequestRepository requestRepo;

    public RequestService(RequestRepository requestRepo) {
        this.requestRepo = requestRepo;
    }

    public List<Request> getAllRequests() {
        return requestRepo.findAll();
    }

    public List<Request> getAllRequestsById(Long employeeId) {
        return requestRepo.findAllByEmployeeId(employeeId);
    }

    public Request findById(Long id){
        return requestRepo.findById(id).get();
    }

    public void saveRequest(Request request){
        requestRepo.save(request);
    }


    public void deleteRequest(@RequestParam Long requestId) {
        requestRepo.deleteById(requestId);

    }
}
