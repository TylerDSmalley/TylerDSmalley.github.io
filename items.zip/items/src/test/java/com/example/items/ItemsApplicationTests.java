package com.example.items;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemsApplicationTests {

    @Test
    void contextLoads() {
    }

}
